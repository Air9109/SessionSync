import prisma from "./database";
import axios from "axios";

export const getRegistry = async (url: string) => {
	return;
}

export const setRegistry = async (url: string) => {
	return;
}