-- AlterTable
ALTER TABLE "Session" ADD COLUMN     "messageId" TEXT;
