-- AlterTable
ALTER TABLE "SessionType" ADD COLUMN     "webhookPing" TEXT;
