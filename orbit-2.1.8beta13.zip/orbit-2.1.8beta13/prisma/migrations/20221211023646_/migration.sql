-- AlterTable
ALTER TABLE "SessionType" ADD COLUMN     "slots" JSONB[];
