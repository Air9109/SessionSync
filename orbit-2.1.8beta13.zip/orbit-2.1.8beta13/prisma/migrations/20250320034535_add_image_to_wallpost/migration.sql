-- AlterTable
ALTER TABLE "wallPost" ADD COLUMN     "image" TEXT;
