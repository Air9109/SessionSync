-- DropForeignKey
ALTER TABLE "rank" DROP CONSTRAINT "rank_userId_fkey";
