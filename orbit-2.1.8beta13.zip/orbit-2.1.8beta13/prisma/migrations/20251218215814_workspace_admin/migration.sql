-- AlterTable
ALTER TABLE "workspaceMember" ADD COLUMN     "isAdmin" BOOLEAN DEFAULT false;
