-- AlterTable
ALTER TABLE "Ally" ADD COLUMN     "discordServer" TEXT,
ADD COLUMN     "theirReps" TEXT[];
