-- AlterTable
ALTER TABLE "ActivitySession" ADD COLUMN     "messages" INTEGER NOT NULL DEFAULT 0;
