ALTER TABLE "user"
ADD COLUMN "birthdayDay" INTEGER,
ADD COLUMN "birthdayMonth" INTEGER;