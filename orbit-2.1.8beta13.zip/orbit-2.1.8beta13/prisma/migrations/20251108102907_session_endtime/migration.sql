-- AlterTable
ALTER TABLE "Session" ADD COLUMN     "duration" INTEGER NOT NULL DEFAULT 30;
