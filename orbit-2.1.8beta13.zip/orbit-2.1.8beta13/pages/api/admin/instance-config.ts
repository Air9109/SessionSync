import type { NextApiRequest, NextApiResponse } from 'next';
import { withSessionRoute } from '@/lib/withSession';
import prisma from '@/utils/database';

export default withSessionRoute(handler);

export async function handler(req: NextApiRequest, res: NextApiResponse) {
	if (!req.session.userid) {
		return res.status(401).json({ error: 'Not authenticated' });
	}

	const user = await prisma.user.findUnique({
		where: { userid: BigInt(req.session.userid) },
		select: { isOwner: true }
	});

	if (!user?.isOwner) {
		return res.status(403).json({ error: 'Access denied. Owner privileges required.' });
	}

	if (req.method === 'GET') {
		try {
		const envClientId = process.env.ROBLOX_CLIENT_ID;
		const envClientSecret = process.env.ROBLOX_CLIENT_SECRET;
		const envRedirectUri = process.env.ROBLOX_REDIRECT_URI;
		const envOAuthOnly = process.env.ROBLOX_OAUTH_ONLY === 'true';
		const usingEnvVars = !!(envClientId && envClientSecret && envRedirectUri);

		if (usingEnvVars) {
			return res.json({
				robloxClientId: '••••••••',
				robloxClientSecret: '••••••••',
				robloxRedirectUri: envRedirectUri,
				oauthOnlyLogin: envOAuthOnly,
				usingEnvVars: true
			});
		}

		const configs = await prisma.instanceConfig.findMany({
			where: {
				key: {
					in: ['robloxClientId', 'robloxClientSecret', 'robloxRedirectUri', 'oauthOnlyLogin']
				}
			}
		});

		const configMap = configs.reduce((acc, config) => {
			acc[config.key] = config.value;
			return acc;
		}, {} as Record<string, any>);

		return res.json({
			robloxClientId: configMap.robloxClientId || '',
			robloxClientSecret: configMap.robloxClientSecret || '',
			robloxRedirectUri: configMap.robloxRedirectUri || '',
			oauthOnlyLogin: configMap.oauthOnlyLogin || false,
			usingEnvVars: false
		});
		} catch (error) {
		console.error('Failed to fetch instance config:', error);
		return res.status(500).json({ error: 'Failed to fetch configuration' });
		}
	}

	if (req.method === 'POST') {
		const envClientId = process.env.ROBLOX_CLIENT_ID;
		const envClientSecret = process.env.ROBLOX_CLIENT_SECRET;
		const envRedirectUri = process.env.ROBLOX_REDIRECT_URI;
		const usingEnvVars = !!(envClientId && envClientSecret && envRedirectUri);

		if (usingEnvVars) {
			return res.status(403).json({ 
				error: 'Cannot modify OAuth configuration when environment variables are set',
				usingEnvVars: true 
			});
		}

		const { robloxClientId, robloxClientSecret, robloxRedirectUri, oauthOnlyLogin } = req.body;

		try {
			const updates = [
				{ key: 'robloxClientId', value: typeof robloxClientId === 'string' ? robloxClientId.trim() : (robloxClientId || '') },
				{ key: 'robloxClientSecret', value: typeof robloxClientSecret === 'string' ? robloxClientSecret.trim() : (robloxClientSecret || '') },
				{ key: 'robloxRedirectUri', value: typeof robloxRedirectUri === 'string' ? robloxRedirectUri.trim() : (robloxRedirectUri || '') },
				{ key: 'oauthOnlyLogin', value: oauthOnlyLogin || false }
			];

			await Promise.all(
				updates.map(({ key, value }) =>
					prisma.instanceConfig.upsert({
						where: { key },
						update: { value, updatedAt: new Date() },
						create: { key, value, updatedAt: new Date() }
					})
				)
			);
			return res.json({ success: true, message: 'Configuration saved successfully' });
		} catch (error) {
			console.error('Failed to save instance config:', error);
			return res.status(500).json({ error: 'Failed to save configuration' });
		}
	}

	return res.status(405).json({ error: 'Method not allowed' });
}